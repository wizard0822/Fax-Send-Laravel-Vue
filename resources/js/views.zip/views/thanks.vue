<template>
	<div class="page">
		<v-container justify-center>
			<v-card flat>
				<v-card-text>
					<v-container grid-list-md>
						<v-layout wrap>
							<v-flex xs12 sm12 md12>
								<p style='color: #000000; font-size: 18px;'> 
								De brief is onderweg naar de gemeente. U ontvangt binnen tien minuten een ontvangstbevestiging. Als dit niet het geval is of als u vragen heeft kunt u contact opnemen via: 036 5254774 of per mail via: support@beslisapp.nl. In de bijlagen vindt U de brieven welke naar de gemeente zijn verzonden.
								</p>
								<p  style='color: #000000; font-size: 18px;'> Met vriendelijke groet, 
								<br> BESLISapp.</p>
							</v-flex>
						</v-layout>
					</v-container>
				</v-card-text>
			</v-card>
		</v-container>
	</div>
</template>

<script>
  	export default {
  		data () {
			return {
			}
		},
  	}
</script>